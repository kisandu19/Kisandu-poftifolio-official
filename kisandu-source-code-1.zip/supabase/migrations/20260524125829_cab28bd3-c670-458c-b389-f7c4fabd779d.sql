-- Create the updated_at function first if it doesn't exist
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create payment_orders table
CREATE TABLE public.payment_orders (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    package_name TEXT NOT NULL,
    original_amount INTEGER NOT NULL,
    discount_applied INTEGER NOT NULL DEFAULT 0,
    final_amount INTEGER NOT NULL,
    payment_method TEXT NOT NULL,
    transaction_id TEXT,
    payer_phone TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add constraints via triggers for enum-like behavior on payment_method and status
ALTER TABLE public.payment_orders 
    ADD CONSTRAINT chk_payment_method 
    CHECK (payment_method IN ('Airtel Money', 'M-Pesa', 'Yaspesa'));

ALTER TABLE public.payment_orders 
    ADD CONSTRAINT chk_status 
    CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled'));

-- Enable RLS
ALTER TABLE public.payment_orders ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can create a payment order
CREATE POLICY "Anyone can create payment orders"
ON public.payment_orders
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Policy: Users can view own orders
CREATE POLICY "Users view own payment orders"
ON public.payment_orders
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Policy: Admins can view all orders
CREATE POLICY "Admins view all payment orders"
ON public.payment_orders
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Policy: Admins can update orders
CREATE POLICY "Admins update payment orders"
ON public.payment_orders
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- Policy: Admins can delete orders
CREATE POLICY "Admins delete payment orders"
ON public.payment_orders
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_payment_orders_updated_at
BEFORE UPDATE ON public.payment_orders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Indexes
CREATE INDEX idx_payment_orders_status ON public.payment_orders(status);
CREATE INDEX idx_payment_orders_user_id ON public.payment_orders(user_id);
CREATE INDEX idx_payment_orders_email ON public.payment_orders(email);