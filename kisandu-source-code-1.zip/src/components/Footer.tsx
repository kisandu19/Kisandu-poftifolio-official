import { Link } from "@tanstack/react-router";
import { Mail, MessageCircle, MapPin } from "lucide-react";
import logo from "@/assets/logo.png";

export function Footer() {
  return (
    <footer className="border-t border-border bg-gradient-hero text-primary-foreground">
      <div className="container mx-auto grid gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <img src={logo} alt="Kisandu" className="h-10 w-10 rounded object-contain" />
            <div>
              <div className="font-display text-base font-bold">KISANDU</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-gold">Web & Graphic</div>
            </div>
          </div>
          <p className="mt-4 text-sm text-primary-foreground/70">Design that inspires. We build beautiful, professional websites & brand visuals for ambitious businesses.</p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-gold">Explore</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            <li><Link to="/services" className="hover:text-gold">Services</Link></li>
            <li><Link to="/portfolio" className="hover:text-gold">Portfolio</Link></li>
            <li><Link to="/pricing" className="hover:text-gold">Pricing</Link></li>
            <li><Link to="/contact" className="hover:text-gold">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-gold">Account</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            <li><Link to="/login" className="hover:text-gold">Login</Link></li>
            <li><Link to="/register" className="hover:text-gold">Create account</Link></li>
            <li><Link to="/dashboard" className="hover:text-gold">My Dashboard</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-gold">Reach us</h4>
          <ul className="space-y-3 text-sm text-primary-foreground/70">
            <li className="flex items-center gap-2"><Mail className="h-4 w-4 text-gold" /><a href="mailto:marcokisandu@gmail.com" className="hover:text-gold">marcokisandu@gmail.com</a></li>
            <li className="flex items-center gap-2"><MessageCircle className="h-4 w-4 text-gold" /><a href="https://wa.me/255693220052" target="_blank" rel="noreferrer" className="hover:text-gold">+255 693 220 052</a></li>
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-gold" /><span>Tanzania</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container mx-auto flex flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-primary-foreground/60 md:flex-row">
          <p>© {new Date().getFullYear()} Kisandu Web & Graphic Solution. All rights reserved.</p>
          <p>Design that inspires.</p>
        </div>
      </div>
    </footer>
  );
}
