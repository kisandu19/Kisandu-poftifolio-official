import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import logo from "@/assets/logo.png";
import { z } from "zod";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Create account — Kisandu" }] }),
  component: Register,
});

const schema = z.object({
  fullName: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  password: z.string().min(8, "Min 8 characters").max(72),
});

function Register() {
  const router = useRouter();
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", password: "" });
  const [subscribe, setSubscribe] = useState(true);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: { full_name: parsed.data.fullName, phone: parsed.data.phone },
      },
    });
    if (error) { setLoading(false); toast.error(error.message); return; }
    // Set subscriber preference
    if (data.user && subscribe) {
      await supabase.from("profiles").update({ is_subscriber: true }).eq("id", data.user.id);
    }
    setLoading(false);
    toast.success("Account created — welcome to Kisandu!");
    router.navigate({ to: "/dashboard" });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="container mx-auto flex flex-1 items-center justify-center px-4 py-16">
        <form onSubmit={submit} className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-card">
          <div className="mb-6 flex items-center gap-3">
            <img src={logo} className="h-10 w-10 rounded object-contain" alt="Kisandu" />
            <div><h1 className="font-display text-2xl font-bold">Create your account</h1><p className="text-sm text-muted-foreground">Join Kisandu in 30 seconds</p></div>
          </div>
          <div className="space-y-4">
            <div><Label htmlFor="fullName">Full name</Label><Input id="fullName" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
            <div><Label htmlFor="email">Email</Label><Input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label htmlFor="phone">Phone (optional)</Label><Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label htmlFor="password">Password</Label><Input id="password" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <label className="flex items-start gap-3 rounded-xl border border-gold/30 bg-gold/10 p-3 text-sm">
              <Checkbox checked={subscribe} onCheckedChange={(v) => setSubscribe(!!v)} className="mt-0.5" />
              <span><span className="font-semibold">Become a subscriber</span> — unlock <span className="font-bold text-gold">15% off</span> on all packages.</span>
            </label>
            <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]">{loading ? "Creating…" : "Create account"}</Button>
          </div>
          <p className="mt-6 text-center text-sm text-muted-foreground">Already a member? <Link to="/login" className="font-semibold text-gold hover:underline">Sign in</Link></p>
        </form>
      </section>
      <Footer />
    </div>
  );
}
