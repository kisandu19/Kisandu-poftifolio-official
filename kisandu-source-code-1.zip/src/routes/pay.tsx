import { createFileRoute, Link, useRouter, useSearch } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Check, Smartphone, CreditCard, Receipt, ArrowLeft, Copy, CheckCheck } from "lucide-react";

export const Route = createFileRoute("/pay")({
  head: () => ({ meta: [{ title: "Checkout — Kisandu" }, { name: "description", content: "Complete your purchase via Airtel Money, M-Pesa, or Yaspesa." }] }),
  component: Pay,
});

const tiers = [
  { name: "Starter", price: 350000, features: ["1-page landing", "Custom design", "Mobile responsive", "Contact form"] },
  { name: "Business", price: 850000, featured: true, features: ["Up to 6 pages", "Custom branding", "CMS / blog", "SEO basics", "WhatsApp & email integration"] },
  { name: "Premium", price: 1800000, features: ["Custom web app", "Admin dashboard", "User accounts", "Payments ready", "Priority support"] },
];

const schema = z.object({
  name: z.string().trim().min(1, "Required").max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  payment_method: z.enum(["Airtel Money", "M-Pesa", "Yaspesa"]),
  transaction_id: z.string().trim().min(3, "Enter a valid transaction ID").max(100),
  payer_phone: z.string().trim().min(9, "Enter your phone number").max(20),
});

const paymentMethods = [
  { id: "Airtel Money", label: "Airtel Money", color: "#D50000", bg: "bg-red-50", border: "border-red-200", text: "text-red-700", iconBg: "bg-red-600" },
  { id: "M-Pesa", label: "M-Pesa", color: "#00A650", bg: "bg-green-50", border: "border-green-200", text: "text-green-700", iconBg: "bg-green-600" },
  { id: "Yaspesa", label: "Yaspesa", color: "#003087", bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", iconBg: "bg-blue-700" },
];

const BUSINESS_NUMBER = "+255 693 220 052";
const BUSINESS_NAME = "Kisandu Web & Graphic Solution";

function Pay() {
  const { user } = useAuth();
  const router = useRouter();
  const search = useSearch({ from: "/pay" }) as { package?: string };
  const selectedPackage = search.package;

  const [isSubscriber, setIsSubscriber] = useState(false);
  const [step, setStep] = useState<"summary" | "pay" | "confirm">("summary");
  const [form, setForm] = useState({ name: "", email: "", phone: "", payment_method: "Airtel Money" as const, transaction_id: "", payer_phone: "" });
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [orderId, setOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      supabase.from("profiles").select("is_subscriber, full_name, phone").eq("id", user.id).maybeSingle()
        .then(({ data }) => {
          setIsSubscriber(!!data?.is_subscriber);
          if (data?.full_name) setForm((f) => ({ ...f, name: data.full_name! }));
          if (data?.phone) setForm((f) => ({ ...f, phone: data.phone!, payer_phone: data.phone! }));
        });
      setForm((f) => ({ ...f, email: user.email ?? "" }));
    }
  }, [user]);

  const tier = tiers.find((t) => t.name === selectedPackage);

  const discount = isSubscriber ? 0.15 : 1;
  const originalAmount = tier?.price ?? 0;
  const discountApplied = isSubscriber ? Math.round(originalAmount * 0.15) : 0;
  const finalAmount = tier ? Math.round(originalAmount * (1 - (isSubscriber ? 0.15 : 0))) : 1;

  const fmt = (n: number) => `TZS ${n.toLocaleString()}`;

  const copyNumber = () => {
    navigator.clipboard.writeText(BUSINESS_NUMBER.replace(/\s/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const submitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    if (!tier) { toast.error("Select a package first"); return; }
    setLoading(true);

    const { data, error } = await supabase.from("payment_orders").insert({
      user_id: user?.id ?? null,
      name: parsed.data.name,
      email: parsed.data.email,
      phone: parsed.data.phone || null,
      package_name: tier.name,
      original_amount: originalAmount,
      discount_applied: discountApplied,
      final_amount: finalAmount,
      payment_method: parsed.data.payment_method,
      transaction_id: parsed.data.transaction_id,
      payer_phone: parsed.data.payer_phone,
      status: "pending",
    }).select("id").single();

    setLoading(false);
    if (error) { toast.error(error.message); return; }

    setOrderId(data?.id ?? null);
    setStep("confirm");
    toast.success("Payment submitted successfully!");
  };

  const selectedMethod = paymentMethods.find((m) => m.id === form.payment_method)!;

  if (!tier) {
    return (
      <div className="flex min-h-screen flex-col">
        <Navbar />
        <section className="container mx-auto flex-1 px-4 py-20">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="font-display text-3xl font-bold">Select a package</h1>
            <p className="mt-2 text-muted-foreground">Choose a package to proceed with payment.</p>
            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              {tiers.map((t) => (
                <div key={t.name} className="rounded-2xl border border-border bg-card p-5 shadow-card text-left">
                  <h3 className="font-display text-lg font-semibold">{t.name}</h3>
                  <div className="mt-2 font-display text-2xl font-bold">{fmt(t.price)}</div>
                  <ul className="mt-4 space-y-1">
                    {t.features.map((f) => <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground"><Check className="h-3.5 w-3.5 text-gold" />{f}</li>)}
                  </ul>
                  <Button asChild className="mt-5 w-full bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]">
                    <Link to="/pay" search={{ package: t.name }}>Select</Link>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />

      <section className="bg-gradient-hero py-16 text-primary-foreground">
        <div className="container mx-auto px-4">
          <Link to="/pricing" className="inline-flex items-center gap-1 text-sm text-primary-foreground/75 hover:text-primary-foreground"><ArrowLeft className="h-4 w-4" /> Back to pricing</Link>
          <h1 className="mt-4 font-display text-3xl font-bold md:text-4xl">Checkout</h1>
          <p className="mt-1 text-primary-foreground/75">Complete your purchase securely.</p>
        </div>
      </section>

      <section className="container mx-auto flex-1 px-4 py-12">
        <div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-5">
          {/* Order Summary */}
          <div className="lg:col-span-2">
            <div className="sticky top-24 space-y-6">
              <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
                <h2 className="font-display text-lg font-semibold">Order summary</h2>
                <div className="mt-4 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Package</span>
                    <span className="font-semibold">{tier.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Base price</span>
                    <span>{fmt(originalAmount)}</span>
                  </div>
                  {isSubscriber && (
                    <div className="flex justify-between text-sm text-gold">
                      <span>Subscriber discount (15%)</span>
                      <span>-{fmt(discountApplied)}</span>
                    </div>
                  )}
                  <div className="h-px bg-border" />
                  <div className="flex justify-between">
                    <span className="font-semibold">Total to pay</span>
                    <span className="font-display text-2xl font-bold text-gold">{fmt(finalAmount)}</span>
                  </div>
                </div>
                <div className="mt-4 rounded-xl bg-secondary/50 p-3 text-xs text-muted-foreground">
                  Pay via Airtel Money, M-Pesa, or Yaspesa. After sending, submit your transaction ID for confirmation.
                </div>
              </div>

              <div className="rounded-2xl border border-gold/30 bg-gold/10 p-5">
                <div className="flex items-center gap-3">
                  <Receipt className="h-5 w-5 text-gold" />
                  <div>
                    <div className="text-sm font-semibold">Need help?</div>
                    <p className="text-xs text-muted-foreground">WhatsApp us after payment for fast confirmation.</p>
                  </div>
                </div>
                <Button asChild size="sm" className="mt-3 w-full bg-[#25D366] hover:bg-[#25D366]/90 text-white">
                  <a href={`https://wa.me/255693220052?text=${encodeURIComponent(`Hello Kisandu, I have sent ${fmt(finalAmount)} for the ${tier.name} package. My transaction ID: `)}`} target="_blank" rel="noreferrer">WhatsApp confirmation</a>
                </Button>
              </div>
            </div>
          </div>

          {/* Checkout Form */}
          <div className="lg:col-span-3">
            {step === "confirm" ? (
              <div className="rounded-2xl border border-gold/40 bg-gold/10 p-8 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gold/20">
                  <CheckCheck className="h-8 w-8 text-gold" />
                </div>
                <h2 className="mt-4 font-display text-2xl font-bold">Payment submitted!</h2>
                <p className="mt-2 text-muted-foreground">We have received your payment details. Our team will verify the transaction and get back to you within 24 hours.</p>
                <div className="mt-6 rounded-xl bg-card p-4 text-left text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Order ID</span><span className="font-mono">{orderId?.slice(0, 8)}...</span></div>
                  <div className="mt-2 flex justify-between"><span className="text-muted-foreground">Amount</span><span className="font-semibold">{fmt(finalAmount)}</span></div>
                  <div className="mt-2 flex justify-between"><span className="text-muted-foreground">Method</span><span className="font-semibold">{form.payment_method}</span></div>
                </div>
                <div className="mt-6 flex gap-3 justify-center">
                  <Button asChild variant="outline"><Link to="/dashboard">Go to dashboard</Link></Button>
                  <Button asChild className="bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]"><Link to="/">Back home</Link></Button>
                </div>
              </div>
            ) : (
              <form onSubmit={submitOrder} className="space-y-6 rounded-2xl border border-border bg-card p-6 shadow-card md:p-8">
                {/* Contact info */}
                <div className="space-y-4">
                  <h3 className="font-display text-lg font-semibold">Your details</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div><Label htmlFor="name">Full name *</Label><Input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                    <div><Label htmlFor="email">Email *</Label><Input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                    <div className="sm:col-span-2"><Label htmlFor="phone">Phone number</Label><Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+255..." /></div>
                  </div>
                </div>

                {/* Payment Method */}
                <div className="space-y-4">
                  <h3 className="font-display text-lg font-semibold">Payment method</h3>
                  <RadioGroup value={form.payment_method} onValueChange={(v) => setForm({ ...form, payment_method: v as typeof form.payment_method })} className="grid gap-3 sm:grid-cols-3">
                    {paymentMethods.map((m) => (
                      <label key={m.id} className={`cursor-pointer rounded-xl border-2 p-4 transition-all ${form.payment_method === m.id ? m.border + " " + m.bg + " ring-1 ring-opacity-50" : "border-border bg-card hover:border-muted-foreground/30"}`} style={form.payment_method === m.id ? { borderColor: m.color, backgroundColor: m.color + "10" } : {}}>
                        <RadioGroupItem value={m.id} id={m.id} className="sr-only" />
                        <div className="flex items-center gap-3">
                          <div className={`flex h-10 w-10 items-center justify-center rounded-lg text-white ${m.iconBg}`}><Smartphone className="h-5 w-5" /></div>
                          <div>
                            <div className="text-sm font-semibold">{m.label}</div>
                            <div className="text-xs text-muted-foreground">Tanzania mobile money</div>
                          </div>
                        </div>
                      </label>
                    ))}
                  </RadioGroup>
                </div>

                {/* Payment Instructions */}
                <div className={`rounded-xl border p-5 ${selectedMethod.border} ${selectedMethod.bg}`} style={{ borderColor: selectedMethod.color + "40", backgroundColor: selectedMethod.color + "08" }}>
                  <h4 className={`text-sm font-semibold ${selectedMethod.text}`} style={{ color: selectedMethod.color }}>How to pay with {selectedMethod.label}</h4>
                  <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                    <p><strong>1.</strong> Dial your {selectedMethod.label} menu or open the app.</p>
                    <p><strong>2.</strong> Select <em>Send Money</em> or <em>Transfer</em>.</p>
                    <p><strong>3.</strong> Enter the business number:</p>
                    <div className="flex items-center gap-2">
                      <code className="rounded-lg bg-card px-3 py-1.5 font-mono text-sm font-semibold border border-border">{BUSINESS_NUMBER}</code>
                      <button type="button" onClick={copyNumber} className="inline-flex items-center gap-1 rounded-md bg-card px-2 py-1 text-xs border border-border hover:bg-secondary">
                        {copied ? <CheckCheck className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                        {copied ? "Copied" : "Copy"}
                      </button>
                    </div>
                    <p><strong>4.</strong> Enter amount: <span className="font-semibold text-foreground">{fmt(finalAmount)}</span></p>
                    <p><strong>5.</strong> Confirm and complete the transaction.</p>
                  </div>
                </div>

                {/* Transaction confirmation */}
                <div className="space-y-4">
                  <h3 className="font-display text-lg font-semibold">Confirm payment</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="payer_phone">Your {selectedMethod.label} phone number *</Label>
                      <Input id="payer_phone" required placeholder="e.g. +255 7XX XXX XXX" value={form.payer_phone} onChange={(e) => setForm({ ...form, payer_phone: e.target.value })} />
                    </div>
                    <div>
                      <Label htmlFor="transaction_id">Transaction ID / Reference *</Label>
                      <Input id="transaction_id" required placeholder="e.g. T123456789" value={form.transaction_id} onChange={(e) => setForm({ ...form, transaction_id: e.target.value })} />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">Enter the transaction reference you received after sending money. We will match it with our records.</p>
                </div>

                <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]">
                  {loading ? "Submitting…" : <><CreditCard className="mr-2 h-4 w-4" />Confirm payment</>}
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFab />
    </div>
  );
}
