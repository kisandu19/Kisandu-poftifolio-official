import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Login — Kisandu" }] }),
  component: Login,
});

function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Welcome back!");
      if (email === "admin@kisandu.co.tz") router.navigate({ to: "/admin" });
      else router.navigate({ to: "/dashboard" });
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="container mx-auto flex flex-1 items-center justify-center px-4 py-16">
        <form onSubmit={submit} className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-card">
          <div className="mb-6 flex items-center gap-3">
            <img src={logo} className="h-10 w-10 rounded object-contain" alt="Kisandu" />
            <div><h1 className="font-display text-2xl font-bold">Welcome back</h1><p className="text-sm text-muted-foreground">Sign in to your account</p></div>
          </div>
          <div className="space-y-4">
            <div><Label htmlFor="email">Email</Label><Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <div><Label htmlFor="password">Password</Label><Input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
            <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]">{loading ? "Signing in…" : "Sign in"}</Button>
          </div>
          <p className="mt-6 text-center text-sm text-muted-foreground">No account? <Link to="/register" className="font-semibold text-gold hover:underline">Create one</Link></p>
        </form>
      </section>
      <Footer />
    </div>
  );
}
