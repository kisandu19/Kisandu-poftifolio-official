import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { Button } from "@/components/ui/button";
import { Check, Sparkles } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/pricing")({
  head: () => ({ meta: [{ title: "Pricing — Kisandu" }] }),
  component: Pricing,
});

const tiers = [
  { name: "Starter", price: 350000, features: ["1-page landing", "Custom design", "Mobile responsive", "Contact form"] },
  { name: "Business", price: 850000, featured: true, features: ["Up to 6 pages", "Custom branding", "CMS / blog", "SEO basics", "WhatsApp & email integration"] },
  { name: "Premium", price: 1800000, features: ["Custom web app", "Admin dashboard", "User accounts", "Payments ready", "Priority support"] },
];

function Pricing() {
  const { user } = useAuth();
  const [isSubscriber, setIsSubscriber] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("is_subscriber").eq("id", user.id).maybeSingle()
      .then(({ data }) => setIsSubscriber(!!data?.is_subscriber));
  }, [user]);

  const toggleSubscribe = async () => {
    if (!user) return;
    setLoading(true);
    const { error } = await supabase.from("profiles").update({ is_subscriber: !isSubscriber }).eq("id", user.id);
    setLoading(false);
    if (error) toast.error(error.message);
    else { setIsSubscriber(!isSubscriber); toast.success(!isSubscriber ? "You're now a subscriber — 15% discount unlocked!" : "Subscription cancelled."); }
  };

  const discount = isSubscriber ? 0.15 : 0;
  const fmt = (n: number) => `TZS ${Math.round(n).toLocaleString()}`;

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="bg-gradient-hero py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-bold md:text-5xl">Simple, honest pricing</h1>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/75">Subscribers get an automatic <span className="font-bold text-gold">15% off</span> every package.</p>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        {user && (
          <div className="mx-auto mb-10 flex max-w-2xl items-center justify-between rounded-2xl border border-gold/30 bg-gold/10 p-5">
            <div className="flex items-center gap-3"><Sparkles className="h-5 w-5 text-gold" />
              <div><div className="font-semibold">{isSubscriber ? "Subscriber discount active" : "Become a subscriber"}</div>
                <p className="text-sm text-muted-foreground">{isSubscriber ? "15% off applied to all tiers below." : "Activate a free subscription to unlock 15% off."}</p>
              </div>
            </div>
            <Button onClick={toggleSubscribe} disabled={loading} variant={isSubscriber ? "outline" : "default"} className={!isSubscriber ? "bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]" : ""}>
              {isSubscriber ? "Cancel" : "Activate"}
            </Button>
          </div>
        )}

        <div className="mx-auto grid max-w-5xl gap-6 md:grid-cols-3">
          {tiers.map((t) => {
            const price = t.price * (1 - discount);
            return (
              <div key={t.name} className={`relative rounded-2xl border bg-card p-7 shadow-card ${t.featured ? "border-gold ring-2 ring-gold/40" : "border-border"}`}>
                {t.featured && <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold px-3 py-1 text-xs font-semibold text-[color:var(--gold-foreground)]">Most popular</span>}
                <h3 className="font-display text-xl font-semibold">{t.name}</h3>
                <div className="mt-4">
                  {discount > 0 && <div className="text-sm text-muted-foreground line-through">{fmt(t.price)}</div>}
                  <div className="font-display text-3xl font-bold">{fmt(price)}</div>
                  <div className="text-xs text-muted-foreground">starting from</div>
                </div>
                <ul className="mt-6 space-y-2">
                  {t.features.map((f) => <li key={f} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4 text-gold" />{f}</li>)}
                </ul>
                <Button asChild className={`mt-6 w-full ${t.featured ? "bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]" : ""}`}>
                  <Link to="/pay" search={{ package: t.name }}>Pay now</Link>
                </Button>
              </div>
            );
          })}
        </div>
        {!user && <p className="mt-10 text-center text-sm text-muted-foreground"><Link to="/register" className="font-semibold text-gold hover:underline">Create an account</Link> and become a subscriber to unlock 15% off.</p>}
      </section>

      <Footer />
      <WhatsAppFab />
    </div>
  );
}
