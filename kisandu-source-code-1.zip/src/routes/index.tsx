import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Globe, Palette, Layers, Zap, Shield, Users } from "lucide-react";
import founder from "@/assets/founder.png";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/")({ component: Index });

const services = [
  { icon: Globe, title: "Web Design & Development", desc: "Modern, responsive websites that convert visitors into customers." },
  { icon: Palette, title: "Graphic Design", desc: "Logos, posters, social media kits and brand identity systems." },
  { icon: Layers, title: "Branding & Identity", desc: "Cohesive brand systems — from concept to deliverable." },
  { icon: Zap, title: "Digital Marketing", desc: "Social media graphics, ads, and content that performs." },
];

function Index() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-hero text-primary-foreground">
        <div className="absolute inset-0 opacity-20" style={{ background: "radial-gradient(800px circle at 20% 30%, var(--gold), transparent 40%)" }} />
        <div className="container relative mx-auto grid gap-12 px-4 py-24 md:grid-cols-2 md:py-32 lg:py-40">
          <div className="flex flex-col justify-center">
            <span className="inline-flex w-fit items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1 text-xs font-medium text-gold">
              <Sparkles className="h-3 w-3" /> Design that inspires
            </span>
            <h1 className="mt-6 font-display text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
              Build a brand <br />that <span className="text-gold">commands attention</span>.
            </h1>
            <p className="mt-6 max-w-lg text-base text-primary-foreground/75 md:text-lg">
              Kisandu Web & Graphic Solution crafts websites, logos and brand visuals that help Tanzanian businesses look world-class and grow faster.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="bg-gold text-[color:var(--gold-foreground)] hover:bg-gold/90 shadow-glow">
                <Link to="/contact">Start your project <ArrowRight className="ml-1 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white/20 bg-white/5 text-primary-foreground hover:bg-white/10">
                <Link to="/portfolio">View portfolio</Link>
              </Button>
            </div>
            <div className="mt-10 flex items-center gap-6 text-xs text-primary-foreground/60">
              <div><div className="text-2xl font-bold text-gold">120+</div>Projects</div>
              <div className="h-10 w-px bg-white/10" />
              <div><div className="text-2xl font-bold text-gold">5★</div>Avg. rating</div>
              <div className="h-10 w-px bg-white/10" />
              <div><div className="text-2xl font-bold text-gold">24h</div>Response</div>
            </div>
          </div>
          <div className="relative flex items-center justify-center">
            <div className="absolute -inset-6 rounded-3xl bg-gradient-brand opacity-30 blur-2xl" />
            <img src={logo} alt="Kisandu logo" className="relative h-72 w-72 object-contain drop-shadow-2xl md:h-96 md:w-96" />
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="container mx-auto px-4 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold md:text-4xl">What we do</h2>
          <p className="mt-3 text-muted-foreground">Full-stack creative services to launch and scale your brand.</p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s) => (
            <div key={s.title} className="group rounded-2xl border border-border bg-card p-6 shadow-card transition-all hover:-translate-y-1 hover:border-gold/40">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-brand text-primary-foreground">
                <s.icon className="h-6 w-6 text-gold" />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section className="bg-secondary/40 py-24">
        <div className="container mx-auto grid items-center gap-12 px-4 md:grid-cols-2">
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-brand opacity-20 blur-xl" />
            <img src={founder} alt="Founder at work" className="relative rounded-2xl object-cover shadow-card" />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-gold">About Kisandu</span>
            <h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">We design with intention.</h2>
            <p className="mt-4 text-muted-foreground">
              From our base in Tanzania, we partner with founders, creators and growing companies to turn ideas into beautifully crafted digital experiences. Every pixel, every typeface, every line of code is chosen on purpose.
            </p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="flex items-start gap-3"><Shield className="mt-1 h-5 w-5 text-gold" /><div><div className="font-semibold">Quality first</div><p className="text-sm text-muted-foreground">Pixel-perfect, accessible, fast.</p></div></div>
              <div className="flex items-start gap-3"><Users className="mt-1 h-5 w-5 text-gold" /><div><div className="font-semibold">Partner mindset</div><p className="text-sm text-muted-foreground">We grow when you grow.</p></div></div>
            </div>
            <Button asChild className="mt-8 bg-primary hover:bg-primary/90"><Link to="/contact">Work with us</Link></Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-24">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-10 text-primary-foreground md:p-16">
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-gold/20 blur-3xl" />
          <div className="relative max-w-2xl">
            <h2 className="font-display text-3xl font-bold md:text-4xl">Ready to look like the brand you want to be?</h2>
            <p className="mt-3 text-primary-foreground/75">Tell us about your project. Subscribers get an automatic discount on every package.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild size="lg" className="bg-gold text-[color:var(--gold-foreground)] hover:bg-gold/90"><Link to="/contact">Send a message</Link></Button>
              <Button asChild size="lg" variant="outline" className="border-white/20 bg-white/5 text-primary-foreground hover:bg-white/10"><Link to="/register">Become a subscriber</Link></Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFab />
    </div>
  );
}
