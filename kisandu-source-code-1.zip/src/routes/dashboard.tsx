import { createFileRoute, useRouter } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useAuth } from "@/lib/auth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Sparkles, Mail, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "My Dashboard — Kisandu" }] }),
  component: Dashboard,
});

interface Msg { id: string; service: string | null; message: string; status: string; created_at: string; }

function Dashboard() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [profile, setProfile] = useState<{ full_name: string | null; is_subscriber: boolean } | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.navigate({ to: "/login" });
  }, [user, loading, router]);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("full_name, is_subscriber").eq("id", user.id).maybeSingle().then(({ data }) => setProfile(data));
    supabase.from("contact_messages").select("id, service, message, status, created_at").eq("user_id", user.id).order("created_at", { ascending: false }).then(({ data }) => setMsgs((data ?? []) as Msg[]));
  }, [user]);

  const toggleSub = async () => {
    if (!user || !profile) return;
    setBusy(true);
    const { error } = await supabase.from("profiles").update({ is_subscriber: !profile.is_subscriber }).eq("id", user.id);
    setBusy(false);
    if (error) toast.error(error.message);
    else { setProfile({ ...profile, is_subscriber: !profile.is_subscriber }); toast.success("Updated"); }
  };

  if (loading || !user) return null;

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="container mx-auto flex-1 px-4 py-12">
        <h1 className="font-display text-3xl font-bold">Hi {profile?.full_name || user.email}</h1>
        <p className="text-muted-foreground">Manage your account and projects.</p>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-card lg:col-span-1">
            <div className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-gold" /><h2 className="font-display text-lg font-semibold">Subscription</h2></div>
            <p className="mt-2 text-sm text-muted-foreground">{profile?.is_subscriber ? "You're a subscriber — 15% off all packages." : "Become a subscriber for 15% off."}</p>
            <Button onClick={toggleSub} disabled={busy} className={`mt-4 w-full ${!profile?.is_subscriber ? "bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]" : ""}`} variant={profile?.is_subscriber ? "outline" : "default"}>
              {profile?.is_subscriber ? "Cancel subscription" : "Activate (free)"}
            </Button>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-card lg:col-span-2">
            <h2 className="font-display text-lg font-semibold">Your messages</h2>
            {msgs.length === 0 ? (
              <p className="mt-3 text-sm text-muted-foreground">You haven't sent any messages yet.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {msgs.map((m) => (
                  <li key={m.id} className="rounded-xl border border-border p-4">
                    <div className="flex items-center justify-between text-xs text-muted-foreground"><span>{m.service || "General"}</span><span>{new Date(m.created_at).toLocaleDateString()}</span></div>
                    <p className="mt-1 text-sm">{m.message}</p>
                    <span className="mt-2 inline-block rounded-full bg-secondary px-2 py-0.5 text-xs">{m.status}</span>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-6 flex gap-3">
              <Button asChild variant="outline"><a href="mailto:marcokisandu@gmail.com"><Mail className="mr-2 h-4 w-4" />Email us</a></Button>
              <Button asChild className="bg-[#25D366] hover:bg-[#25D366]/90 text-white"><a href="https://wa.me/255693220052" target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" />WhatsApp</a></Button>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}
