import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { Button } from "@/components/ui/button";
import { Check, Globe, Palette, Layers, Zap, Camera, PenTool } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({ meta: [{ title: "Services — Kisandu Web & Graphic Solution" }, { name: "description", content: "Web design, graphic design, branding, social media kits and more." }] }),
  component: Services,
});

const items = [
  { icon: Globe, title: "Web Design & Development", points: ["Responsive websites", "Landing pages", "E-commerce", "SEO foundations"] },
  { icon: Palette, title: "Logo & Brand Identity", points: ["Logo design", "Brand guidelines", "Color & typography", "Stationery"] },
  { icon: Layers, title: "Graphic Design", points: ["Posters & flyers", "Business cards", "Brochures", "Banners"] },
  { icon: Zap, title: "Social Media Kits", points: ["Instagram & Facebook posts", "Story templates", "Ad creatives", "Highlights covers"] },
  { icon: Camera, title: "Photo Retouching", points: ["Product photo cleanup", "Color grading", "Background removal", "Catalogue prep"] },
  { icon: PenTool, title: "UI/UX Design", points: ["App wireframes", "Prototypes", "Design systems", "Hand-off to dev"] },
];

function Services() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="bg-gradient-hero py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-bold md:text-5xl">Services</h1>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/75">End-to-end creative & digital services for serious brands.</p>
        </div>
      </section>
      <section className="container mx-auto grid gap-6 px-4 py-20 md:grid-cols-2 lg:grid-cols-3">
        {items.map((s) => (
          <div key={s.title} className="rounded-2xl border border-border bg-card p-6 shadow-card transition-all hover:-translate-y-1 hover:border-gold/40">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary"><s.icon className="h-6 w-6 text-gold" /></div>
            <h3 className="mt-5 font-display text-xl font-semibold">{s.title}</h3>
            <ul className="mt-4 space-y-2">
              {s.points.map((p) => <li key={p} className="flex items-center gap-2 text-sm text-muted-foreground"><Check className="h-4 w-4 text-gold" />{p}</li>)}
            </ul>
          </div>
        ))}
      </section>
      <section className="container mx-auto px-4 pb-24 text-center">
        <Button asChild size="lg" className="bg-gold hover:bg-gold/90 text-[color:var(--gold-foreground)]"><Link to="/contact">Request a quote</Link></Button>
      </section>
      <Footer />
      <WhatsAppFab />
    </div>
  );
}
