import { createFileRoute, useRouter } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useAuth } from "@/lib/auth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Users, MessageSquare, Sparkles, ShieldCheck, CreditCard, Smartphone } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Kisandu" }] }),
  component: Admin,
});

interface Msg { id: string; name: string; email: string; phone: string | null; service: string | null; message: string; status: string; created_at: string; }
interface Profile { id: string; full_name: string | null; phone: string | null; is_subscriber: boolean; created_at: string; }
interface Payment { id: string; name: string; email: string; phone: string | null; package_name: string; original_amount: number; discount_applied: number; final_amount: number; payment_method: string; transaction_id: string | null; payer_phone: string | null; status: string; notes: string | null; created_at: string; }

type TabType = "messages" | "users" | "payments";

function Admin() {
  const { user, isAdmin, loading } = useAuth();
  const router = useRouter();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [tab, setTab] = useState<TabType>("messages");

  useEffect(() => {
    if (loading) return;
    if (!user) { router.navigate({ to: "/login" }); return; }
    if (!isAdmin) { router.navigate({ to: "/dashboard" }); }
  }, [user, isAdmin, loading, router]);

  const reload = async () => {
    const [m, u, p] = await Promise.all([
      supabase.from("contact_messages").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("payment_orders").select("*").order("created_at", { ascending: false }),
    ]);
    setMsgs((m.data ?? []) as Msg[]);
    setUsers((u.data ?? []) as Profile[]);
    setPayments((p.data ?? []) as Payment[]);
  };
  useEffect(() => { if (isAdmin) reload(); }, [isAdmin]);

  const setMsgStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("contact_messages").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Updated"); reload(); }
  };
  const setPayStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("payment_orders").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Updated"); reload(); }
  };
  const delMsg = async (id: string) => {
    if (!confirm("Delete this message?")) return;
    const { error } = await supabase.from("contact_messages").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); reload(); }
  };
  const delPay = async (id: string) => {
    if (!confirm("Delete this payment record?")) return;
    const { error } = await supabase.from("payment_orders").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); reload(); }
  };
  const toggleSub = async (p: Profile) => {
    const { error } = await supabase.from("profiles").update({ is_subscriber: !p.is_subscriber }).eq("id", p.id);
    if (error) toast.error(error.message); else reload();
  };

  if (loading || !user || !isAdmin) return null;

  const newCount = msgs.filter((m) => m.status === "new").length;
  const subCount = users.filter((u) => u.is_subscriber).length;
  const pendingPay = payments.filter((p) => p.status === "pending").length;

  const methodBadge = (method: string) => {
    const colors: Record<string, string> = {
      "Airtel Money": "bg-red-50 text-red-700 border-red-200",
      "M-Pesa": "bg-green-50 text-green-700 border-green-200",
      "Yaspesa": "bg-blue-50 text-blue-700 border-blue-200",
    };
    return <span className={`rounded-full border px-2 py-0.5 text-xs font-medium ${colors[method] ?? "bg-secondary text-secondary-foreground"}`}>{method}</span>;
  };

  const fmt = (n: number) => `TZS ${n.toLocaleString()}`;

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="container mx-auto flex-1 px-4 py-10">
        <div className="flex items-center gap-2"><ShieldCheck className="h-6 w-6 text-gold" /><h1 className="font-display text-3xl font-bold">Admin Panel</h1></div>
        <p className="text-muted-foreground">Manage messages, payments, users and subscriptions.</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-4">
          <Stat icon={MessageSquare} label="Messages" value={msgs.length} />
          <Stat icon={CreditCard} label="Payments" value={payments.length} accent={pendingPay > 5} />
          <Stat icon={Users} label="Users" value={users.length} />
          <Stat icon={Sparkles} label="Subscribers" value={subCount} accent />
        </div>

        <div className="mt-8 flex gap-2 border-b border-border overflow-x-auto">
          <TabBtn active={tab === "messages"} onClick={() => setTab("messages")}>Messages {newCount > 0 && <span className="ml-2 rounded-full bg-gold px-2 py-0.5 text-xs text-[color:var(--gold-foreground)]">{newCount}</span>}</TabBtn>
          <TabBtn active={tab === "payments"} onClick={() => setTab("payments")}>Payments {pendingPay > 1 && <span className="ml-2 rounded-full bg-red-500 px-2 py-0.5 text-xs text-white">{pendingPay}</span>}</TabBtn>
          <TabBtn active={tab === "users"} onClick={() => setTab("users")}>Users</TabBtn>
        </div>

        {tab === "messages" && (
          <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr><th className="p-3">From</th><th className="p-3">Service</th><th className="p-3">Message</th><th className="p-3">Status</th><th className="p-3">Date</th><th className="p-3"></th></tr>
              </thead>
              <tbody>
                {msgs.map((m) => (
                  <tr key={m.id} className="border-t border-border align-top">
                    <td className="p-3">
                      <div className="font-semibold">{m.name}</div>
                      <div className="text-xs text-muted-foreground">{m.email}</div>
                      {m.phone && <div className="text-xs text-muted-foreground">{m.phone}</div>}
                    </td>
                    <td className="p-3 text-muted-foreground">{m.service || "—"}</td>
                    <td className="p-3 max-w-md"><p className="line-clamp-3">{m.message}</p></td>
                    <td className="p-3">
                      <select value={m.status} onChange={(e) => setMsgStatus(m.id, e.target.value)} className="rounded border border-border bg-background px-2 py-1 text-xs">
                        <option value="new">new</option><option value="in_progress">in progress</option><option value="done">done</option>
                      </select>
                    </td>
                    <td className="p-3 text-xs text-muted-foreground">{new Date(m.created_at).toLocaleDateString()}</td>
                    <td className="p-3"><Button size="sm" variant="ghost" onClick={() => delMsg(m.id)}>Delete</Button></td>
                  </tr>
                ))}
                {msgs.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No messages yet.</td></tr>}
              </tbody>
            </table>
          </div>
        )}

        {tab === "payments" && (
          <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr><th className="p-3">Customer</th><th className="p-3">Package</th><th className="p-3">Amount</th><th className="p-3">Method</th><th className="p-3">Transaction</th><th className="p-3">Status</th><th className="p-3">Date</th><th className="p-3"></th></tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-t border-border align-top">
                    <td className="p-3">
                      <div className="font-semibold">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.email}</div>
                      {p.phone && <div className="text-xs text-muted-foreground">{p.phone}</div>}
                    </td>
                    <td className="p-3 font-medium">{p.package_name}</td>
                    <td className="p-3">
                      <div className="font-semibold">{fmt(p.final_amount)}</div>
                      {p.discount_applied > 0 && <div className="text-xs text-muted-foreground line-through">{fmt(p.original_amount)}</div>}
                    </td>
                    <td className="p-3">{methodBadge(p.payment_method)}</td>
                    <td className="p-3">
                      <div className="font-mono text-xs">{p.transaction_id || "—"}</div>
                      {p.payer_phone && <div className="text-xs text-muted-foreground flex items-center gap-1"><Smartphone className="h-3 w-3" />{p.payer_phone}</div>}
                    </td>
                    <td className="p-3">
                      <select value={p.status} onChange={(e) => setPayStatus(p.id, e.target.value)} className="rounded border border-border bg-background px-2 py-1 text-xs">
                        <option value="pending">pending</option><option value="confirmed">confirmed</option><option value="completed">completed</option><option value="cancelled">cancelled</option>
                      </select>
                    </td>
                    <td className="p-3 text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="p-3"><Button size="sm" variant="ghost" onClick={() => delPay(p.id)}>Delete</Button></td>
                  </tr>
                ))}
                {payments.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No payments yet.</td></tr>}
              </tbody>
            </table>
          </div>
        )}

        {tab === "users" && (
          <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr><th className="p-3">Name</th><th className="p-3">Phone</th><th className="p-3">Subscriber</th><th className="p-3">Joined</th><th className="p-3"></th></tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-border">
                    <td className="p-3 font-semibold">{u.full_name || "—"}</td>
                    <td className="p-3 text-muted-foreground">{u.phone || "—"}</td>
                    <td className="p-3">{u.is_subscriber ? <span className="rounded-full bg-gold/20 px-2 py-0.5 text-xs font-semibold text-gold">YES</span> : <span className="text-xs text-muted-foreground">no</span>}</td>
                    <td className="p-3 text-xs text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
                    <td className="p-3"><Button size="sm" variant="outline" onClick={() => toggleSub(u)}>{u.is_subscriber ? "Remove sub" : "Make sub"}</Button></td>
                  </tr>
                ))}
                {users.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No users yet.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <Footer />
    </div>
  );
}

function Stat({ icon: Icon, label, value, accent }: { icon: React.ComponentType<{ className?: string }>; label: string; value: number; accent?: boolean }) {
  return (
    <div className={`rounded-2xl border p-5 shadow-card ${accent ? "border-gold/40 bg-gold/10" : "border-border bg-card"}`}>
      <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground"><Icon className="h-4 w-4" />{label}</div>
      <div className="mt-2 font-display text-3xl font-bold">{value}</div>
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={`border-b-2 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${active ? "border-gold text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>{children}</button>;
}
