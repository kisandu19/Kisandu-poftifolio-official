import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";

export const Route = createFileRoute("/portfolio")({
  head: () => ({ meta: [{ title: "Portfolio — Kisandu" }] }),
  component: Portfolio,
});

const projects = [
  { title: "Boutique Coffee Shop", tag: "Brand + Web", color: "from-amber-500 to-red-500" },
  { title: "Mzima Logistics", tag: "Web Platform", color: "from-sky-500 to-indigo-600" },
  { title: "Safari Tours TZ", tag: "Landing Page", color: "from-emerald-500 to-teal-600" },
  { title: "Pulse Fitness", tag: "Brand Identity", color: "from-rose-500 to-pink-600" },
  { title: "Kahawa Records", tag: "Album Artwork", color: "from-violet-500 to-purple-700" },
  { title: "Bahari Realty", tag: "Web + Print", color: "from-cyan-500 to-blue-700" },
];

function Portfolio() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="bg-gradient-hero py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-bold md:text-5xl">Selected Work</h1>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/75">A glimpse of recent projects we've shipped.</p>
        </div>
      </section>
      <section className="container mx-auto grid gap-6 px-4 py-20 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => (
          <div key={p.title} className="group relative overflow-hidden rounded-2xl shadow-card">
            <div className={`aspect-[4/3] bg-gradient-to-br ${p.color} transition-transform group-hover:scale-105`} />
            <div className="absolute inset-0 bg-black/0 transition-colors group-hover:bg-black/40" />
            <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
              <div className="text-xs uppercase tracking-widest text-gold">{p.tag}</div>
              <div className="font-display text-lg font-semibold">{p.title}</div>
            </div>
          </div>
        ))}
      </section>
      <Footer />
      <WhatsAppFab />
    </div>
  );
}
