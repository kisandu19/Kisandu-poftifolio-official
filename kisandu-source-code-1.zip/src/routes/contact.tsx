import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { WhatsAppFab } from "@/components/WhatsAppFab";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, MessageCircle, MapPin } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — Kisandu" }, { name: "description", content: "Get in touch with Kisandu via form, email or WhatsApp." }] }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(1, "Required").max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  service: z.string().trim().max(100).optional().or(z.literal("")),
  message: z.string().trim().min(5, "Tell us a bit more").max(2000),
});

function Contact() {
  const { user } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", phone: "", service: "", message: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.from("contact_messages").insert({
      ...parsed.data, user_id: user?.id ?? null, phone: parsed.data.phone || null, service: parsed.data.service || null,
    });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success("Message sent! We'll reply within 24 hours."); setForm({ name: "", email: "", phone: "", service: "", message: "" }); }
  };

  const wa = `https://wa.me/255693220052?text=${encodeURIComponent(`Hello Kisandu, I'm ${form.name || "interested"} — ${form.message || "I'd like to discuss a project."}`)}`;

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <section className="bg-gradient-hero py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-bold md:text-5xl">Let's talk</h1>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/75">No account needed — message us via form, email or WhatsApp.</p>
        </div>
      </section>

      <section className="container mx-auto grid gap-10 px-4 py-20 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-1">
          <a href="mailto:marcokisandu@gmail.com" className="flex items-start gap-3 rounded-2xl border border-border bg-card p-5 transition-colors hover:border-gold/40">
            <Mail className="mt-1 h-5 w-5 text-gold" />
            <div><div className="font-semibold">Email</div><div className="text-sm text-muted-foreground">marcokisandu@gmail.com</div></div>
          </a>
          <a href="https://wa.me/255693220052" target="_blank" rel="noreferrer" className="flex items-start gap-3 rounded-2xl border border-border bg-card p-5 transition-colors hover:border-gold/40">
            <MessageCircle className="mt-1 h-5 w-5 text-[#25D366]" />
            <div><div className="font-semibold">WhatsApp</div><div className="text-sm text-muted-foreground">+255 693 220 052</div></div>
          </a>
          <div className="flex items-start gap-3 rounded-2xl border border-border bg-card p-5">
            <MapPin className="mt-1 h-5 w-5 text-gold" />
            <div><div className="font-semibold">Location</div><div className="text-sm text-muted-foreground">Tanzania (remote-friendly)</div></div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-border bg-card p-6 shadow-card lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label htmlFor="name">Full name *</Label><Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div><Label htmlFor="email">Email *</Label><Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
            <div><Label htmlFor="phone">Phone</Label><Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label htmlFor="service">Service</Label><Input id="service" placeholder="Web design, logo, branding…" value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} /></div>
          </div>
          <div><Label htmlFor="message">Your message *</Label><Textarea id="message" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required /></div>
          <div className="flex flex-wrap gap-3">
            <Button type="submit" disabled={loading} className="bg-primary hover:bg-primary/90">{loading ? "Sending…" : "Send message"}</Button>
            <Button asChild type="button" variant="outline"><a href={wa} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" />WhatsApp instead</a></Button>
            <Button asChild type="button" variant="ghost"><a href={`mailto:marcokisandu@gmail.com?subject=${encodeURIComponent("Project enquiry")}&body=${encodeURIComponent(form.message)}`}><Mail className="mr-2 h-4 w-4" />Email</a></Button>
          </div>
        </form>
      </section>
      <Footer />
      <WhatsAppFab />
    </div>
  );
}
